import xbmcaddon
import xbmcgui
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('camel')
 
line1 = "Xin chào!"
line2 = "NUC đã đến và đi như 1 vị thần"
line3 = "Tạm biệt..."
 
xbmcgui.Dialog().ok(addonname, line1, line2, line3)
